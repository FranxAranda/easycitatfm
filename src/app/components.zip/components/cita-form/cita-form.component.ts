import { Component } from '@angular/core';

@Component({
  selector: 'app-cita-form',
  standalone: true,
  template: `<p>Cita Form Works!</p>`
})
export class CitaFormComponent {}

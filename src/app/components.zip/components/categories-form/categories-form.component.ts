import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { CategoriesService } from '/Users/franaranda/Documents/easycita-tfm/easycita-tfm/frontend/src/app/services/categories.service'; // <- importa tu servicio

@Component({
  selector: 'app-categories-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule
  ],
  templateUrl: './categories-form.component.html',
  styleUrls: ['./categories-form.component.css']
})
export class CategoriesFormComponent {

  categoryForm!: FormGroup;
  error: string | null = null;
  success: string | null = null; // <- mensaje de éxito

  constructor(private fb: FormBuilder, private categoriesService: CategoriesService) {}

  ngOnInit() {
    this.categoryForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2)]],
      description: ['']
    });
  }

  saveCategory() {
    if (this.categoryForm.invalid) {
      this.error = "Formulario inválido";
      this.success = null;
      return;
    }

    const categoryData = this.categoryForm.value;

    // Llamada al servicio
    this.categoriesService.createCategory(categoryData).subscribe({
      next: (res: any) => {
        console.log("CATEGORY saved:", res);
        this.success = "Categoría guardada correctamente";
        this.error = null;
        this.categoryForm.reset(); // limpiar formulario
      },
      error: (err: any) => {
        console.error("Error saving category:", err);
        this.error = "Error al guardar la categoría";
        this.success = null;
      }
    });
  }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-cita-list',
  standalone: true,
  template: `<p>Cita List Works!</p>`
})
export class CitaListComponent {}

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {
  // Aquí puedes añadir datos dinámicos si más adelante los traes de un servicio
  totalUsers: number = 123;
  totalCategories: number = 8;
  totalPosts: number = 34;

  latestPosts = [
    { title: 'Primer post', author: 'Fran', date: '25/11/2025' },
    { title: 'Segundo post', author: 'Fran', date: '26/11/2025' }
  ];
}
